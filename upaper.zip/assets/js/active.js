(function($){
	"use strict";
	
	jQuery(document).ready(function($){
		
	});
	
	
	jQuery(window).on("load", function(){
		
	});
	
})(jQuery);
